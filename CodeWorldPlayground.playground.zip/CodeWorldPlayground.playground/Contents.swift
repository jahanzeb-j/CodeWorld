//: ###Code World Game

// Created By: Jahanzeb Jabbar
// Date: 2019-03-22

import SpriteKit
import PlaygroundSupport
import CoreMotion
import GameplayKit
import AVFoundation

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var starfield:SKEmitterNode!
    var player:SKSpriteNode!

    
    var scoreLabel:SKLabelNode!
    var score:Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }

    var gameTimer:Timer!
    var codeTimer:Timer!
    //Name of the stone images
    var stonesS = ["stone", "stone2", "stone3"]
    // Show codes droping from sky
    var codings = ["{..}", "print()", "var","for","let","=","abc","ij","true","in","if","123"]
    // Syntexss need to be completed
    var codingSyntax = ["let abc = 123", "if true {..}","for abc in ij"]
    
    var result = "";
     var codeLabel:SKLabelNode!
    
    let stonesCategory:UInt32 = 0x1 << 1
    let photonTorpedoCategory:UInt32 = 0x1 << 0
    let rocketCategory:UInt32 = 0x1 << 2
    let codeCategory:UInt32 = 0x1 << 3


    
    let motionManger = CMMotionManager()
    var xAcceleration:CGFloat = 0
    
    override func didMove(to view: SKView) {
        
        //Background
        let background = SKSpriteNode(imageNamed: "background")
        background.size = CGSize(width: 1000, height: 800)
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        self.addChild(background)
        
        //Stars field from sks file
        starfield = SKEmitterNode(fileNamed: "Starfield")
        starfield.position = CGPoint(x: 100, y: 1470)
        starfield.advanceSimulationTime(10)
        self.addChild(starfield)
        
        starfield.zPosition = 0
        
        //Define our player Rocket
        player = SKSpriteNode(imageNamed: "rocketjet")
        player.scale(to: CGSize(width: 80, height: 150))
        player.position = CGPoint(x: self.frame.size.width / 2, y: player.size.height / 2 + 0)
        player.physicsBody = SKPhysicsBody(rectangleOf: player.size)
        player.physicsBody?.isDynamic = true
        player.physicsBody?.categoryBitMask = rocketCategory
        player.physicsBody?.contactTestBitMask = stonesCategory
        player.physicsBody?.collisionBitMask = 0
        self.addChild(player)
        
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        self.physicsWorld.contactDelegate = self
        //to show score label
        scoreLabel = SKLabelNode(text: "Score: 0")
        scoreLabel.position = CGPoint(x: 100, y: self.frame.size.height - 40)
        scoreLabel.fontName = "Chalkduster"
        scoreLabel.fontSize = 25
        scoreLabel.fontColor = UIColor.white
        score = 0
        self.addChild(scoreLabel)
        
        //Choose Syntax randomly
        let randomIndex = Int(arc4random_uniform(UInt32(codingSyntax.count)))
    
        result = codingSyntax[randomIndex]
        codeLabel = SKLabelNode(text: result)
        codeLabel.position = CGPoint(x: 100, y: self.frame.size.height - 90)
        codeLabel.fontName = "Roman"
        codeLabel.fontSize = 25
        codeLabel.fontColor = UIColor.white
        self.addChild(codeLabel)
        //game timer for the stones
        gameTimer = Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(addStone), userInfo: nil, repeats: true)
        //game timer for the codes droping from sky
       codeTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(addCode), userInfo: nil, repeats: true)
        
        
        motionManger.accelerometerUpdateInterval = 0.2
        motionManger.startAccelerometerUpdates(to: OperationQueue.current!) { (data:CMAccelerometerData?, error:Error?) in
            if let accelerometerData = data {
                let acceleration = accelerometerData.acceleration
                self.xAcceleration = CGFloat(acceleration.x) * 0.75 + self.xAcceleration * 0.25
            }
        }
        
            //Background Sound
        
            playSound(fileName: "background-music", type: .background)
    }
    
    
    
    @objc func addStone () {
        stonesS = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: stonesS) as! [String]
        
        let stone = SKSpriteNode(imageNamed: stonesS[0])
        stone.scale(to: CGSize(width: 80, height: 150))
        let randomstonePosition = GKRandomDistribution(lowestValue: 0, highestValue: 414)
        let position = CGFloat(randomstonePosition.nextInt())
        stone.position = CGPoint(x: position, y: self.frame.size.height + stone.size.height)
        stone.physicsBody = SKPhysicsBody(rectangleOf: stone.size)
        stone.physicsBody?.isDynamic = true
        stone.physicsBody?.categoryBitMask = stonesCategory
        stone.physicsBody?.contactTestBitMask = photonTorpedoCategory
        stone.physicsBody?.collisionBitMask = 0
        
        self.addChild(stone)
        
        let animationDuration:TimeInterval = 6
        var actionArray = [SKAction]()
        actionArray.append(SKAction.move(to: CGPoint(x: position, y: -stone.size.height), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        stone.run(SKAction.sequence(actionArray))
        
        
    }
    
    @objc func addCode () {
        
        codings = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: codings) as! [String]
        let code = SKLabelNode(text: codings[0])
        code.fontName = "Chalkduster"
        let randomstonePosition = GKRandomDistribution(lowestValue: 0, highestValue: 414)
        let position = CGFloat(randomstonePosition.nextInt())
        code.position = CGPoint(x: position, y: self.frame.size.height + code.frame.size.height)
        code.physicsBody = SKPhysicsBody(rectangleOf: code.frame.size)
        code.physicsBody?.isDynamic = true
        code.physicsBody?.categoryBitMask = codeCategory
        code.physicsBody?.contactTestBitMask = photonTorpedoCategory
        code.physicsBody?.collisionBitMask = 0
        self.addChild(code)
        
        let animationDuration:TimeInterval = 6
        var actionArray = [SKAction]()
        actionArray.append(SKAction.move(to: CGPoint(x: position, y: -code.frame.size.height), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        code.run(SKAction.sequence(actionArray))
        
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        super.touchesBegan(touches, with: event)
        //Move the Rocket towards the x position of touches
        var location = touches.first!.location(in: self)
        location.y = player.position.y
        let actionMove = SKAction.move(to: location, duration: 1.0)
        self.player!.run(actionMove)
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
       //fire the torpedo on touch
        fireTorpedo()
    }
    
    
    func fireTorpedo() {
        self.run(SKAction.playSoundFileNamed("torpedo.mp3", waitForCompletion: false))
        
        let torpedoNode = SKSpriteNode(imageNamed: "torpedo")
        torpedoNode.position.x = player.position.x
        torpedoNode.position.y = player.position.y + 10
        torpedoNode.physicsBody = SKPhysicsBody(circleOfRadius: torpedoNode.size.width / 2)
        torpedoNode.physicsBody?.isDynamic = true
        torpedoNode.physicsBody?.categoryBitMask = photonTorpedoCategory
        torpedoNode.physicsBody?.contactTestBitMask = stonesCategory
        torpedoNode.physicsBody?.collisionBitMask = 0
        torpedoNode.physicsBody?.usesPreciseCollisionDetection = true
        
        self.addChild(torpedoNode)
        let animationDuration:TimeInterval = 0.3
        var actionArray = [SKAction]()
        actionArray.append(SKAction.move(to: CGPoint(x: player.position.x, y: self.frame.size.height + 10), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        torpedoNode.run(SKAction.sequence(actionArray))
        
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody:SKPhysicsBody
        var secondBody:SKPhysicsBody
        
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        }else{
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if (firstBody.categoryBitMask & photonTorpedoCategory) != 0 && (secondBody.categoryBitMask & stonesCategory) != 0 {
            //Action when torpedo collides with stone
            torpedoDidCollideWithstone(torpedoNode: firstBody.node as! SKSpriteNode, stoneNode: secondBody.node as! SKSpriteNode)
        }
        else if (firstBody.categoryBitMask & stonesCategory) != 0 && (secondBody.categoryBitMask & rocketCategory) != 0 {
            //Action when stone collides with rocker
            stoneDidCollideWithRocket(stoneNode: firstBody.node as! SKSpriteNode, rocketNode: secondBody.node as! SKSpriteNode)
        }
        else if (firstBody.categoryBitMask & photonTorpedoCategory) != 0 && (secondBody.categoryBitMask & codeCategory) != 0 {
            //Action when torpedo collides with Stone
             torpedoDidCollideWithcode(torpedoNode: firstBody.node as! SKSpriteNode, codeNode: secondBody.node as! SKLabelNode)
            
        }
    }
    
    
    func torpedoDidCollideWithstone (torpedoNode:SKSpriteNode, stoneNode:SKSpriteNode) {
        
        let explosion = SKEmitterNode(fileNamed: "ExplosionParticle")!
        explosion.position = stoneNode.position
        self.addChild(explosion)
        self.run(SKAction.playSoundFileNamed("Explosion.wav", waitForCompletion: false))
        torpedoNode.removeFromParent()
        stoneNode.removeFromParent()
        self.run(SKAction.wait(forDuration: 2)) {
            explosion.removeFromParent()
        }
        // Increase score by 5
        score += 5
        
        let scoreDisplay = SKLabelNode(text: "+5")
        scoreDisplay.position =  CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        scoreDisplay.fontName = "Chalkduster"
        scoreDisplay.fontSize = 45
        scoreDisplay.fontColor = UIColor.white
        self.addChild(scoreDisplay)
        self.run(SKAction.wait(forDuration: 0.5)) {
            scoreDisplay.removeFromParent()
        }
        
    }
    
    func torpedoDidCollideWithcode (torpedoNode:SKSpriteNode, codeNode:SKLabelNode) {
        
        let explosion = SKEmitterNode(fileNamed: "ExplosionParticle")!
        explosion.position = codeNode.position
        self.addChild(explosion)
        self.run(SKAction.playSoundFileNamed("code-hit.wav", waitForCompletion: false))
        torpedoNode.removeFromParent()
        codeNode.removeFromParent()
        
        self.run(SKAction.wait(forDuration: 2)) {
            explosion.removeFromParent()}
        var isFind = false
        let scoreDisplay = SKLabelNode()
        let i = codeNode.text?.count
        print(result.prefix(i!))
        
/*      Main Logics of the Game.
         First check if the collided code was the first element of Syntax
         if true: score plus 5
            drop that code word from the syntax
         if not the first element then - 5
         if the all the syntax code line is completed then regenerate the new line
 */
        if(result.prefix(i!).elementsEqual(codeNode.text!)) {
            
                score += 5
                isFind = true
                scoreDisplay.text = "+5"
            
                let sl = result.dropFirst(i!+1)
                result = String(sl)
                print(String(sl))
                if(sl.count == 0){
                    let randomIndex = Int(arc4random_uniform(UInt32(codingSyntax.count)))
                    result = codingSyntax[randomIndex]
                    codeLabel.text = result
                }
                else{
                    codeLabel.text = String(sl)
                    print(codeLabel.text!)
                }
                
                
            }

        if !isFind && score > 0{
            
            score -= 5;
            scoreDisplay.text = "-5"
        }
        
        scoreDisplay.position =  CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        scoreDisplay.fontName = "Chalkduster"
        scoreDisplay.fontSize = 45
        scoreDisplay.fontColor = UIColor.white
        self.addChild(scoreDisplay)
        
        self.run(SKAction.wait(forDuration: 0.5)) {
            scoreDisplay.removeFromParent()
        }
       
        
    }
    func stoneDidCollideWithRocket (stoneNode:SKSpriteNode, rocketNode:SKSpriteNode) {
        
        // Play the Explore .sks scene of fire
        let explosion = SKEmitterNode(fileNamed: "ExplosionParticle")!
        explosion.position = rocketNode.position
        self.addChild(explosion)
        //Play the Sound
        self.run(SKAction.playSoundFileNamed("Explosion.wav", waitForCompletion: false))
        //Remove the stone
        stoneNode.removeFromParent()
        self.run(SKAction.wait(forDuration: 2)) {
            explosion.removeFromParent()
        }
        // Score -5 because of stone collide with rocket
        if(score>0){
            score -= 5
        //Display the score Label
        let scoreDisplay = SKLabelNode(text: "-5")
        scoreDisplay.position =  CGPoint(x: self.frame.size.width/2, y: self.frame.size.height/2)
        scoreDisplay.fontName = "Chalkduster"
        scoreDisplay.fontSize = 45
        scoreDisplay.fontColor = UIColor.white
        self.addChild(scoreDisplay)

        self.run(SKAction.wait(forDuration: 0.5)) {
            scoreDisplay.removeFromParent()
        }
        }
        
        
    }
    
    override func didSimulatePhysics() {
        
        player.position.x += xAcceleration * 50
        
        if player.position.x < -20 {
            player.position = CGPoint(x: self.size.width + 20, y: player.position.y)
        }else if player.position.x > self.size.width + 20 {
            player.position = CGPoint(x: -20, y: player.position.y)
        }
        
    }
    /**
     The player for the background sound.
     */
    var playermusic: AVAudioPlayer?
    /**
     An enum that describes the sound types.
     */
    enum SoundType {
        case background
    }
  

    func playSound(fileName: String, type: SoundType) {
        guard let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            
            switch type {
            case .background:
                do {
                    playermusic = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
                    
                    guard let playermusic = playermusic else { return }
                    playermusic.play()
                }
        
            }
        } catch let error {
            debugPrint(error.localizedDescription)
        }
    }
    
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }

}
//Start Screen Scene
class GameSceneStart: SKScene {

    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "startpage")
        background.size = CGSize(width: 500, height: 700)
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        self.addChild(background)
       
    }
    
      override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
     
        let transition:SKTransition = SKTransition.flipHorizontal(withDuration: 1)
        let scene:SKScene = GameScene(size: self.size)
        self.view?.presentScene(scene, transition: transition)
        
    }
    override func update(_ currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}



let size = CGSize(width: 500, height: 700)
let scene = GameSceneStart(size: size)
let view = SKView(frame: CGRect(origin: CGPoint.zero, size: size))
view.presentScene(scene)
PlaygroundPage.current.liveView = view

